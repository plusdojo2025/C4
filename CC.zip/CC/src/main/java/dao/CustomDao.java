package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import dto.CustomDto;

/***
 * @param <DTO>
 * データ型「PRIMARY_KEY_TYPE」はクラス定義の時に指定（DTOクラス名、IdPwDto、・・）
 * {@code 例）public class DAOクラス名 extends CustomDto<DTOクラス名>　}
 * {@code 例）public class IdPwDAO extends CustomDto<IdPwDto>　}
 */
public abstract class CustomDao<DTO extends CustomDto> {
	
	/***
	 * コネクションを取得
	 * ※オーバーライド禁止(final付与)
	 */
	protected final Connection connect() {
		Connection conn = null;
		try {
			
			// JDBCドライバを読み込む
			Class.forName("com.mysql.cj.jdbc.Driver");
	
			// データベースに接続する
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/webapp2?"
					+ "characterEncoding=utf8&useSSL=false&serverTimezone=GMT%2B9&rewriteBatchedStatements=true",
					"root", "password");
			
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		return conn;
	}

	/***
	 * コネクションを切断
	 * ※オーバーライド禁止(final付与)
	 */
	protected final void close(Connection conn) {
		// データベースを切断
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	/***
	 * テーブルからレコードを検索
	 */
	public abstract List<DTO> select(DTO dto);
	/***
	 * テーブルへ1レコードを追加
	 */
	public abstract boolean insert(DTO dto);
	/***
	 * テーブルの1レコードを更新
	 */
	public abstract boolean update(DTO dto);
	/***
	 * テーブルの1レコードを削除
	 */
	public abstract boolean delete(DTO dto);

}
