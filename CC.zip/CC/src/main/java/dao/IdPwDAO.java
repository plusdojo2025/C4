package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.IdPwDto;

public class IdPwDAO extends CustomDao<IdPwDto> {
	
	public boolean isLoginOK(IdPwDto idpw) {
		Connection conn = connect();
		boolean loginResult = false;

		try {

			// SELECT文を準備する
			String sql = "SELECT count(*) FROM IdPw WHERE id=? AND pw=?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, idpw.getId());
			pStmt.setString(2, idpw.getPw());

			// SELECT文を実行し、結果表を取得する
			ResultSet rs = pStmt.executeQuery();

			// ユーザーIDとパスワードが一致するユーザーがいれば結果をtrueにする
			rs.next();
			if (rs.getInt("count(*)") == 1) {
				loginResult = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			loginResult = false;
		} finally {
			// データベースを切断
			close(conn);
		}

		// 結果を返す
		return loginResult;
	}

	@Override
	public List<IdPwDto> select(IdPwDto dto) {
		Connection conn = connect();
		List<IdPwDto> result = new ArrayList<>();

		try {

			// SELECT文を準備する
			String sql = "SELECT * FROM IdPw WHERE id=?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, dto.getId());

			// SELECT文を実行し、結果表を取得する
			ResultSet rs = pStmt.executeQuery();

			// ユーザーIDとパスワードが一致するユーザーがいれば結果をtrueにする
			while (rs.next()) {
				IdPwDto idpw = new IdPwDto(
						rs.getString("id"),
						rs.getString("pw")
				);
				result.add(idpw);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// データベースを切断
			close(conn);
		}

		// 結果を返す
		return result;
	}

	@Override
	public boolean insert(IdPwDto dto) {
		Connection conn = connect();
		boolean result = false;

		try {
			// SQL文を準備する
			String sql = "INSERT INTO IdPw(id,pw) VALUES(?,?)";
			PreparedStatement pStmt = conn.prepareStatement(sql);

			// SQL文を完成させる
			pStmt.setString(1, dto.getId());
			pStmt.setString(2, dto.getPw());

			// SQL文を実行する
			if (pStmt.executeUpdate() == 1) {
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// データベースを切断
			close(conn);
		}

		// 結果を返す
		return result;
	}

	@Override
	public boolean update(IdPwDto dto) {
		Connection conn = connect();
		boolean result = false;

		try {
			// SQL文を準備する
			String sql = "UPDATE IdPw SET pw=? WHERE id=?";
			PreparedStatement pStmt = conn.prepareStatement(sql);

			// SQL文を完成させる
			pStmt.setString(1, dto.getPw());
			pStmt.setString(2, dto.getId());

			// SQL文を実行する
			if (pStmt.executeUpdate() == 1) {
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// データベースを切断
			close(conn);
		}

		// 結果を返す
		return result;
	}

	@Override
	public boolean delete(IdPwDto dto) {
		Connection conn = connect();
		boolean result = false;

		try {
			// SQL文を準備する
			String sql = "DELETE FROM IdPw WHERE id=?";
			PreparedStatement pStmt = conn.prepareStatement(sql);

			// SQL文を完成させる
			pStmt.setString(1, dto.getId());

			// SQL文を実行する
			if (pStmt.executeUpdate() == 1) {
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// データベースを切断
			close(conn);
		}

		// 結果を返す
		return result;
	}

}
