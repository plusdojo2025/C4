package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public abstract class CustomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/***
	 * ログインしていないことを確認、ログインしていないときはログイン画面へリダイレクト
	 */
	protected final boolean checkNoneLogin(HttpServletRequest request, HttpServletResponse response) 
			throws IOException {
		HttpSession session = request.getSession();
		boolean isNoneLogin = (session.getAttribute("id") == null);
		if (isNoneLogin) {
			// ログイン画面へリダイレクト
			response.sendRedirect("login");
		}
		return isNoneLogin;
	}

	/***
	 * ログインしていることを確認、ログインしているときはログイン後に遷移予定の画面へリダイレクト
	 */
	protected final boolean checkDoneLogin(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		HttpSession session = request.getSession();
		boolean isDoneLogin = (session.getAttribute("id") != null);
		if (isDoneLogin) {
			// ログイン後に遷移予定の画面へリダイレクト
			response.sendRedirect("menu");
		}
		return isDoneLogin;
	}
	
	@Override
	protected abstract void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException;
	@Override
	protected abstract void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException;
	
}
