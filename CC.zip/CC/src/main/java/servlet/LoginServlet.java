package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.IdPwDAO;
import dto.IdPwDto;
import dto.LoginUser;
import dto.Result;

@WebServlet("/login")
public class LoginServlet extends CustomServlet {
	private static final long serialVersionUID = 1L;

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
    	if (checkDoneLogin(request, response)) {
    		// ログインしているときは、ログイン画面を開かない
    		return;
    	}
    	
		// ログインページにフォワードする
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/login.jsp");
		dispatcher.forward(request, response);
	}

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
    	if (checkDoneLogin(request, response)) {
    		// ログインしているときは、ログイン画面を開かない
    		return;
    	}
    	
		// リクエストパラメータを取得する
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");

		// ログイン処理を行う
		IdPwDAO iDao = new IdPwDAO();

//		iDao.insert(new IdPwDto(id, pw));
//		iDao.select(new IdPwDto(id, pw));
//		iDao.update(new IdPwDto(id, pw));
//		iDao.delete(new IdPwDto(id, pw));
		
		if (iDao.isLoginOK(new IdPwDto(id, pw))) { // ログイン成功
			// セッションスコープにIDを格納する
			HttpSession session = request.getSession();
			session.setAttribute("id", new LoginUser(id));

			// メニューサーブレットにリダイレクトする
			response.sendRedirect("menu");
		} else { // ログイン失敗
			// セッションスコープに、タイトル、メッセージ、戻り先を格納する
			HttpSession session = request.getSession();
			session.setAttribute("result", new Result("ログイン失敗！", "IDまたはPWに間違いがあります。", "/webapp/LoginServlet"));

			// ログインサーブレットにリダイレクトする
			response.sendRedirect("login");
		}
	}

}
